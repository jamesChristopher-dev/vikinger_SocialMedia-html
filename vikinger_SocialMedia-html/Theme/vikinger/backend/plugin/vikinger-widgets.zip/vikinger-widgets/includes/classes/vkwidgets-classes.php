<?php
/**
 * Vikinger Widgets
 * 
 * @since 1.0.0
 */

/**
 * Post List Widget
 */
require_once VKWIDGETS_PATH . '/includes/classes/Vikinger_PostsList_Widget.php';

/**
 * Mixed Post List Widget
 */
require_once VKWIDGETS_PATH . '/includes/classes/Vikinger_MixedPostsList_Widget.php';

/**
 * Post Grid Widget
 */
require_once VKWIDGETS_PATH . '/includes/classes/Vikinger_PostsGrid_Widget.php';

?>