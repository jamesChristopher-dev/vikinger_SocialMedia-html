<?php
/**
 * Vikinger Reactions - BuddyPress Integration AJAX
 * 
 * @since 1.0.0
 */

/**
 * ACTIVITY AJAX
 */
require_once VKREACT_BP_PATH . '/includes/ajax/vkreact-bp-ajax-activity.php';

?>