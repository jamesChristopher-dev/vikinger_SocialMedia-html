<?php
/**
 * Vikinger Reactions - BuddyPress Integration functions
 * 
 * @since 1.0.0
 */

/**
 * ACTIVITY functions
 */
require_once VKREACT_BP_PATH . '/includes/functions/vkreact-bp-functions-activity.php';

?>