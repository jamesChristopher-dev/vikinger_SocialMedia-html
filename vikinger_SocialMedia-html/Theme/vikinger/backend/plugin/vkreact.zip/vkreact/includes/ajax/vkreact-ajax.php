<?php
/**
 * Vikinger Reactions AJAX
 * 
 * @since 1.0.0
 */

/**
 * REACTION AJAX
 */
require_once VKREACT_PATH . '/includes/ajax/vkreact-ajax-reaction.php';

/**
 * POST AJAX
 */
require_once VKREACT_PATH . '/includes/ajax/vkreact-ajax-post.php';

/**
 * POSTCOMMENT AJAX
 */
require_once VKREACT_PATH . '/includes/ajax/vkreact-ajax-postcomment.php';

?>