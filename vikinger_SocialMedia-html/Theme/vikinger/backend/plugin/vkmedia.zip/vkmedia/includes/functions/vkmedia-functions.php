<?php
/**
 * Vikinger Media - functions
 * 
 * @since 1.0.0
 */

/**
 * MEDIA functions
 */
require_once VKMEDIA_PATH . '/includes/functions/vkmedia-functions-media.php';

?>